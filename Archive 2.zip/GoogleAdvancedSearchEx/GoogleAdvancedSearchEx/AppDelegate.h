//
//  AppDelegate.h
//  GoogleAdvancedSearchEx
//
//  Created by Mohamed Alaa El-Din on 11/11/13.
//  Copyright (c) 2013 Mohamed Alaa El-Din. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
