//
//  TopicsListView.h
//  rssDemo
//
//  Created by Mohamed Alaa El-Din on 10/29/13.
//  Copyright (c) 2013 Mohamed Alaa El-Din. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "NSString+HTML.h"
#import "MWFeedParser.h"
#import "MWFeedParser.h"

@interface TopicsListView : UIViewController <UITableViewDelegate,UITableViewDataSource,MWFeedParserDelegate>
{
    MWFeedParser *feedParser;
	NSMutableArray *parsedItems;
	
	// Displaying
	NSArray *itemsToDisplay;
	NSDateFormatter *formatter;
}
@property (weak, nonatomic) IBOutlet UITableView *tableData;
@property (nonatomic, retain) NSArray *itemsToDisplay;
@property (nonatomic,strong) NSString *rssUrl;
@end
