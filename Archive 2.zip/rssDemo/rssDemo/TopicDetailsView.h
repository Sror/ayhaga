//
//  TopicDetailsView.h
//  rssDemo
//
//  Created by Mohamed Alaa El-Din on 10/29/13.
//  Copyright (c) 2013 Mohamed Alaa El-Din. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MWFeedItem.h"

@interface TopicDetailsView : UIViewController <UIWebViewDelegate>
{
    UIActivityIndicatorView *indicator;
}
@property (nonatomic,strong) MWFeedItem *item;
@property (weak, nonatomic) IBOutlet UIWebView *webView;
@end
