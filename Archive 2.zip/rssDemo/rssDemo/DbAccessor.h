//
//  DbAccessor.h
//  rssDemo
//
//  Created by Mohamed Alaa El-Din on 10/29/13.
//  Copyright (c) 2013 Mohamed Alaa El-Din. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <sqlite3.h>
@interface DbAccessor : NSObject
{
    NSString  *databasePath;
    sqlite3   *contactDB;
    sqlite3* database;
}

- (BOOL) saveInjData :(NSString *)type :(NSString *)location  :(int)mcgGlobal :(int)mcg : (NSString *)date;
- (NSMutableArray *) getInjections;
@end
