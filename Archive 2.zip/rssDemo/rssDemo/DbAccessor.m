//
//  DbAccessor.m
//  rssDemo
//
//  Created by Mohamed Alaa El-Din on 10/29/13.
//  Copyright (c) 2013 Mohamed Alaa El-Din. All rights reserved.
//

#import "DbAccessor.h"

@implementation DbAccessor

-(void)initializeDatabase
{
    NSString *path = [self createEditableDatabase];
    if (sqlite3_open([path UTF8String],  & database) == SQLITE_OK)
    {
    }
    else
        sqlite3_close(database);
}

- (NSString*) createEditableDatabase
{
    // Check to see if editable database already exists
    BOOL success;
    NSFileManager *fileManager = [NSFileManager defaultManager];
    NSError *error;
    NSArray *paths = NSSearchPathForDirectoriesInDomains
    (NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDir = [paths objectAtIndex:0];
    NSString *writableDB = [documentsDir
                            stringByAppendingPathComponent:@"Mobile.db"];
    success = [fileManager fileExistsAtPath:writableDB];
    if (success)
        return writableDB;
    
    // The editable database does not exist
    // Copy the default DB to the application Documents directory.
    NSString *defaultPath = [[[NSBundle mainBundle] resourcePath]
                             stringByAppendingPathComponent:@"Mobile.db"];
    success = [fileManager copyItemAtPath:defaultPath
                                   toPath:writableDB error: & error];
    if (!success)
    {
        NSAssert1(0, @"Failed to create writable database file:’%@’.",
                  [error localizedDescription]);
        return writableDB;
    }
    else
    {
        return writableDB;
    }
}


- (BOOL) saveInjData :(NSString *)type :(NSString *)location  :(int)mcgGlobal :(int)mcg : (NSString *)date
{
    NSString *path = [self createEditableDatabase];
    if (sqlite3_open([path UTF8String],  & database) != SQLITE_OK)
    {
        sqlite3_close(database);
        return false;
    }
    
    sqlite3_stmt *statement;
    NSString *command = [NSString stringWithFormat:@"INSERT INTO injections (type,location,mcgGlobal,mcg,date) VALUES('%@','%@','%d','%d','%@');",type,location,mcgGlobal,mcg,date];
    
    int sqlResult = sqlite3_prepare_v2(database, [command UTF8String], -1,  & statement, 0);
    
    if ( sqlResult== SQLITE_OK )
    {
        if(sqlite3_step(statement) != SQLITE_DONE )
        {
            NSLog( @"Error: %s", sqlite3_errmsg(database) );
        }
        else
        {
            sqlite3_step(statement);
            sqlite3_finalize(statement);
        }
        
        sqlite3_finalize(statement);
        return TRUE;
    }
    else
    {
        return FALSE;
    }
}


- (NSMutableArray *) getInjections
{
    
    NSString *path = [self createEditableDatabase];
    if (sqlite3_open([path UTF8String],  & database) != SQLITE_OK)
    {
        sqlite3_close(database);
        return false;
    }
    
    sqlite3_stmt *statement;
    NSString *command= [NSString stringWithFormat:@"SELECT * FROM injections"];
    
    int sqlResult = sqlite3_prepare_v2(database, [command UTF8String], -1,  & statement, 0);
   // NSMutableArray *InjecList = [[NSMutableArray alloc] init] ;
    
    
    if ( sqlResult== SQLITE_OK)
    {
        
        while (sqlite3_step(statement) == SQLITE_ROW) {
           /* InjectionModel *im =[[InjectionModel alloc]init];
            
            int r_id = sqlite3_column_int(statement, 0);
            im.Rid=r_id;
            
            char *type = (char *)sqlite3_column_text(statement,1);
            im.type =[NSString stringWithUTF8String:type];
            
            char *location = (char *)sqlite3_column_text(statement,2);
            im.location =[NSString stringWithUTF8String:location];
            
            int mcgGlobal = sqlite3_column_int(statement, 3);
            im.mcgGlobal =mcgGlobal;
            
            int mcg = sqlite3_column_int(statement, 4);
            im.mcg =mcg;
            
            char *date = (char *)sqlite3_column_text(statement,5);
            im.date =[NSString stringWithUTF8String:date];
            
            [InjecList addObject:im];*/
        }
        
        sqlite3_finalize(statement);
    }
    else
    {
        return FALSE;
    }
    return 0;//InjecList;
}


@end
