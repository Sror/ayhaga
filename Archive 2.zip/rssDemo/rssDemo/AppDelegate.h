//
//  AppDelegate.h
//  rssDemo
//
//  Created by Mohamed Alaa El-Din on 10/28/13.
//  Copyright (c) 2013 Mohamed Alaa El-Din. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Dashboard.h"
@class Dashboard;
@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;
@property (nonatomic,strong) Dashboard *dashboard;
@property (strong, nonatomic) UINavigationController *navigation;
@end
