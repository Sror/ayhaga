//
//  Dashboard.m
//  GoogleNews
//
//  Created by Mohamed Alaa El-Din on 10/24/13.
//  Copyright (c) 2013 Mohamed Alaa El-Din. All rights reserved.
//

#import "Dashboard.h"
#import "TopicsListView.h"
@interface Dashboard ()

@end

@implementation Dashboard
@synthesize tableData;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.title = @"الكتاب";
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone)
        indicator = [[UIActivityIndicatorView alloc] initWithFrame:CGRectMake(self.view.frame.size.width/2 -30 , self.view.frame.size.height/2, 50, 50)];
    else
        indicator = [[UIActivityIndicatorView alloc] initWithFrame:CGRectMake(330, 500, 100, 100)];
    
    authors = [[NSMutableArray alloc] initWithObjects:@"بلال فضل",@"عمرو حمزاوي",@"محمد علي خيري",@"فهمي هويدي",@"عمرو خفاجة",@"عماد الدين حسين",@"باسم يوسف" ,nil];
    rssUrls = [[NSMutableArray alloc] initWithObjects:@"BilalFadl",@"amr-hamzawe",@"Muhammad-Ali-Khearer",@"fahmy-howaidy",@"amr-khafaga",@"emad-el-din-hussein",@"Basem-youssef", nil];

}


-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSString *CellIdentifier = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    
    if(cell == nil)
    {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
    }
    
    // Configure the cell...
    cell.textLabel.text = [authors objectAtIndex:indexPath.row];
    
    return cell;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 75;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return authors.count;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    TopicsListView *topicsListView = [[TopicsListView alloc] init];
    topicsListView.rssUrl = [rssUrls objectAtIndex:indexPath.row];
    [self.navigationController pushViewController:topicsListView animated:YES];
    
}




- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

@end
