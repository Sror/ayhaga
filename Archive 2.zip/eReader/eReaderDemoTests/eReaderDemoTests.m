//
//  eReaderDemoTests.m
//  eReaderDemoTests
//
//  Created by mohamed Alaa El-Din on 10/11/13.
//  Copyright (c) 2013 mohamed Alaa El-Din. All rights reserved.
//

#import <XCTest/XCTest.h>

@interface eReaderDemoTests : XCTestCase

@end

@implementation eReaderDemoTests

- (void)setUp
{
    [super setUp];
    // Put setup code here. This method is called before the invocation of each test method in the class.
}

- (void)tearDown
{
    // Put teardown code here. This method is called after the invocation of each test method in the class.
    [super tearDown];
}

- (void)testExample
{
    XCTFail(@"No implementation for \"%s\"", __PRETTY_FUNCTION__);
}

@end
