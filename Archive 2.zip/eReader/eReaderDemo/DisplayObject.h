//
//  DisplayObject.h
//  eReaderDemo
//
//  Created by Mohamed Alaa El-Din on 10/22/13.
//  Copyright (c) 2013 mohamed Alaa El-Din. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <FacebookSDK/FacebookSDK.h>
@interface DisplayObject : UIViewController
{
    NSArray *json;
    UIActivityIndicatorView *indicator;
}
@property (strong, nonatomic) NSArray *data;
@property (strong, nonatomic) NSString *pageId;
@end
