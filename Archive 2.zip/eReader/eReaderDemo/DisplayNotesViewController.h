//
//  DisplayNotesViewController.h
//  eReaderDemo
//
//  Created by Mohamed Alaa El-Din on 10/22/13.
//  Copyright (c) 2013 mohamed Alaa El-Din. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ASIHTTPRequest.h"
#import "ASIFormDataRequest.h"
@interface DisplayNotesViewController : UIViewController <UIWebViewDelegate>
{
    UIActivityIndicatorView *indicator;
}
@property (weak, nonatomic) IBOutlet UIWebView *noteWebView;
@property (strong, nonatomic) NSString *pageId;
@property (nonatomic, strong) NSString *url;
@property (weak, nonatomic) IBOutlet UIScrollView *container;
@end
