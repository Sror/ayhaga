//
//  UIView+UIView_Gradient.h
//  eReaderDemo
//
//  Created by Mohamed Alaa El-Din on 11/4/13.
//  Copyright (c) 2013 mohamed Alaa El-Din. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIView (Gradient)
-(void) addLinearUniformGradient:(NSArray *)stopColors;
@end