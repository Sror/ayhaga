//
//  DbAccessor.m
//  rssDemo
//
//  Created by Mohamed Alaa El-Din on 10/29/13.
//  Copyright (c) 2013 Mohamed Alaa El-Din. All rights reserved.
//

#import "DbAccessor.h"

@implementation DbAccessor

-(void)initializeDatabase
{
    NSString *path = [self createEditableDatabase];
    if (sqlite3_open([path UTF8String],  & database) == SQLITE_OK)
    {
    }
    else
        sqlite3_close(database);
}

- (NSString*) createEditableDatabase
{
    // Check to see if editable database already exists
    BOOL success;
    NSFileManager *fileManager = [NSFileManager defaultManager];
    NSError *error;
    NSArray *paths = NSSearchPathForDirectoriesInDomains
    (NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDir = [paths objectAtIndex:0];
    NSString *writableDB = [documentsDir
                            stringByAppendingPathComponent:@"mobile.db"];
    success = [fileManager fileExistsAtPath:writableDB];
    if (success)
        return writableDB;
    
    // The editable database does not exist
    // Copy the default DB to the application Documents directory.
    NSString *defaultPath = [[[NSBundle mainBundle] resourcePath]
                             stringByAppendingPathComponent:@"mobile.db"];
    success = [fileManager copyItemAtPath:defaultPath
                                   toPath:writableDB error: & error];
    if (!success)
    {
        NSAssert1(0, @"Failed to create writable database file:’%@’.",
                  [error localizedDescription]);
        return writableDB;
    }
    else
    {
        return writableDB;
    }
}


- (NSMutableArray *) getUrls
{
    
    NSString *path = [self createEditableDatabase];
    if (sqlite3_open([path UTF8String],  & database) != SQLITE_OK)
    {
        sqlite3_close(database);
        return false;
    }
    
    sqlite3_stmt *statement;
    NSString *command= [NSString stringWithFormat:@"SELECT SourceUrl FROM Query"];
    
    int sqlResult = sqlite3_prepare_v2(database, [command UTF8String], -1,  & statement, 0);
    NSMutableArray *urlsList = [[NSMutableArray alloc] init] ;
    
    
    if ( sqlResult== SQLITE_OK)
    {
        while (sqlite3_step(statement) == SQLITE_ROW)
        {
            char *url = (char *)sqlite3_column_text(statement,0);
             [urlsList addObject:[NSString stringWithUTF8String:url]];
        }
        
        sqlite3_finalize(statement);
    }
    else
    {
        return FALSE;
    }
    return urlsList;
}


-(BOOL)savePagesLikes:(NSString *)pageId :(int)pageLikes
{
    NSString *path = [self createEditableDatabase];
    if (!(sqlite3_open([path UTF8String],  &database) == SQLITE_OK)) {
        sqlite3_close(database);
        return false;
    }
    
    sqlite3_stmt *statement;
    NSString *command = [NSString stringWithFormat:@"INSERT INTO pages (page_id, page_likes) VALUES('%@', '%d');", pageId,pageLikes];
    
    int sqlResult = sqlite3_prepare_v2(database, [command UTF8String], -1,  &statement, 0);
    
    if (sqlResult == SQLITE_OK) {
        if(sqlite3_step(statement) == SQLITE_DONE) {
            sqlite3_step(statement);
            sqlite3_finalize(statement);
        } else {
            NSLog(@"Error: %s", sqlite3_errmsg(database));
        }
        
        sqlite3_finalize(statement);
        return YES;
    }
    else {
        return NO;
    }
}

- (NSMutableArray *) getPagesSorted
{
    
    NSString *path = [self createEditableDatabase];
    if (sqlite3_open([path UTF8String],  & database) != SQLITE_OK)
    {
        sqlite3_close(database);
        return false;
    }
    
    sqlite3_stmt *statement;
    NSString *command= [NSString stringWithFormat:@"SELECT * FROM pages order by page_likes desc"];
    
    int sqlResult = sqlite3_prepare_v2(database, [command UTF8String], -1,  & statement, 0);
    NSMutableArray *urlsList = [[NSMutableArray alloc] init] ;
    
    
    if ( sqlResult== SQLITE_OK)
    {
        while (sqlite3_step(statement) == SQLITE_ROW)
        {
            PagesModel *pages = [[PagesModel alloc] init];
            pages.rId      = sqlite3_column_int(statement, 0);
            char *pageId = (char *)sqlite3_column_text(statement,1);
            pages.pageId = [NSString stringWithUTF8String:pageId];
             pages.pageLikes     = sqlite3_column_int(statement, 2);
            [urlsList addObject:pages];
        }
        
        sqlite3_finalize(statement);
    }
    else
    {
        return FALSE;
    }
    return urlsList;
}

-(BOOL) deletePages
{
    NSString *path = [self createEditableDatabase];
    if (sqlite3_open([path UTF8String],  & database) != SQLITE_OK)
    {
        sqlite3_close(database);
        return false;
    }
    sqlite3_stmt *statement;
    
    NSString *command = [NSString stringWithFormat:@"DELETE FROM pages"];
    int sqlResult = sqlite3_prepare_v2(database, [command UTF8String], -1,  & statement, NULL);
    if ( sqlResult== SQLITE_OK) {
        sqlite3_step(statement);
        sqlite3_finalize(statement);
        
        return TRUE;
    }
    else
    {
        return FALSE;
    }
}



-(BOOL)savePosts:(NSString *)msg :(NSString *)link :(NSString *)name
{
    NSString *path = [self createEditableDatabase];
    if (!(sqlite3_open([path UTF8String],  &database) == SQLITE_OK)) {
        sqlite3_close(database);
        return false;
    }
    
    sqlite3_stmt *statement;
    
    NSString *command = [NSString stringWithFormat:@"INSERT INTO posts (message, link, name) VALUES('%@', '%@', '%@');", msg,link,name];
    
    int sqlResult = sqlite3_prepare_v2(database, [command UTF8String], -1,  &statement, 0);
    
    if (sqlResult == SQLITE_OK) {
        if(sqlite3_step(statement) == SQLITE_DONE) {
            sqlite3_step(statement);
            sqlite3_finalize(statement);
        } else {
            NSLog(@"Error: %s", sqlite3_errmsg(database));
        }
        
        sqlite3_finalize(statement);
        return YES;
    }
    else {
        NSLog(@"Error: %s", sqlite3_errmsg(database));
        NSLog(@"save la23");
        return NO;
    }
}

- (NSMutableArray *) getPosts
{
    
    NSString *path = [self createEditableDatabase];
    if (sqlite3_open([path UTF8String],  & database) != SQLITE_OK)
    {
        sqlite3_close(database);
        return false;
    }
    
    sqlite3_stmt *statement;
    NSString *command= [NSString stringWithFormat:@"SELECT * FROM posts"];
    
    int sqlResult = sqlite3_prepare_v2(database, [command UTF8String], -1,  & statement, 0);
    NSMutableArray *postsList = [[NSMutableArray alloc] init] ;
    
    
    if ( sqlResult== SQLITE_OK)
    {
        while (sqlite3_step(statement) == SQLITE_ROW)
        {
            PostsModel *post = [[PostsModel alloc] init];
            char *msg = (char *)sqlite3_column_text(statement,1);
            post.msg      = [NSString stringWithUTF8String:msg];
            
            char *link = (char *)sqlite3_column_text(statement,2);
            post.link      = [NSString stringWithUTF8String:link];
            
            char *name = (char *)sqlite3_column_text(statement,3);
            post.name      = [NSString stringWithUTF8String:name];
            
            [postsList addObject:post];
        }
        
        sqlite3_finalize(statement);
    }
    else
    {
        NSLog(@"get mesh sha3'ala");
        return FALSE;
    }
    return postsList;
}

-(BOOL) deletePosted
{
    NSString *path = [self createEditableDatabase];
    if (sqlite3_open([path UTF8String],  & database) != SQLITE_OK)
    {
        sqlite3_close(database);
        return false;
    }
    sqlite3_stmt *statement;
    
    NSString *command = [NSString stringWithFormat:@"DELETE FROM posts"];
    int sqlResult = sqlite3_prepare_v2(database, [command UTF8String], -1,  & statement, NULL);
    if ( sqlResult== SQLITE_OK) {
        sqlite3_step(statement);
        sqlite3_finalize(statement);
        
        return TRUE;
    }
    else
    {
        return FALSE;
    }
}

@end
