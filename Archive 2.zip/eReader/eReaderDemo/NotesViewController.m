//
//  NotesViewController.m
//  eReaderDemo
//
//  Created by Mohamed Alaa El-Din on 10/22/13.
//  Copyright (c) 2013 mohamed Alaa El-Din. All rights reserved.
//

#import "NotesViewController.h"

@interface NotesViewController ()

@end

@implementation NotesViewController
@synthesize pageId,tableData;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone)
        indicator = [[UIActivityIndicatorView alloc] initWithFrame:CGRectMake(self.view.frame.size.width/2 -30 , self.view.frame.size.height/2, 50, 50)];
    else
        indicator = [[UIActivityIndicatorView alloc] initWithFrame:CGRectMake(330, 500, 100, 100)];
    
    indicator.color = [UIColor blackColor];
    [self.view addSubview:indicator];
    [indicator startAnimating];
    
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    NSString *accessToken = [defaults objectForKey:@"FBAccessTokenKey"];
    NSString *urlString = [NSString stringWithFormat:@"https://graph.facebook.com/%@/notes?access_token=%@", pageId,[accessToken stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding] ];
    NSURL *url = [NSURL URLWithString:urlString];
    ASIHTTPRequest *request = [ASIHTTPRequest requestWithURL:url];
    [request setDidFinishSelector:@selector(loadNotes:)];
    
    [request setDelegate:self];
    [request startAsynchronous];
    
    
   
}

- (void)loadNotes:(ASIHTTPRequest *)request
{
    NSString *responseString = [request responseString];
    
    NSData *JSONContent = [responseString dataUsingEncoding:NSUTF8StringEncoding];
    NSError *error;
   json = [NSJSONSerialization JSONObjectWithData:JSONContent
                                           options:kNilOptions error:&error];
    noOfRecords = json.count;
    
    if(noOfRecords == 1)
    {
        [[[UIAlertView alloc] initWithTitle:@"Not found" message:@"Result not found!" delegate:nil cancelButtonTitle:@"ok" otherButtonTitles:Nil, nil] show];
        [indicator stopAnimating];
        return;
    }
    
    tempArray= [[NSMutableArray alloc] init];
    for(int i = 0; i < noOfRecords ; i++)
        [tempArray addObject:[[[json valueForKey:@"data"] valueForKey:@"subject"] objectAtIndex:i]];
    
    [tableData reloadData];
    [indicator stopAnimating];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSString *CellIdentifier = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    
    if(cell == nil)
    {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
    }
    // Configure the cell...
    cell.textLabel.text = [tempArray objectAtIndex:indexPath.row];
    
    return cell;}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 75;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return noOfRecords;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    DisplayNotesViewController *displayObject = [[DisplayNotesViewController alloc] init];
    displayObject.pageId = [[[json valueForKey:@"data"] valueForKey:@"id"] objectAtIndex:indexPath.row];
    
    [self.navigationController pushViewController:displayObject animated:YES];
}

@end
