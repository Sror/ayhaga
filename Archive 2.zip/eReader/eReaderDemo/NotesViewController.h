//
//  NotesViewController.h
//  eReaderDemo
//
//  Created by Mohamed Alaa El-Din on 10/22/13.
//  Copyright (c) 2013 mohamed Alaa El-Din. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ASIHTTPRequest.h"
#import "ASIFormDataRequest.h"
#import "DisplayNotesViewController.h"
@interface NotesViewController : UIViewController <UITableViewDataSource,UITableViewDelegate>
{
    NSMutableArray *tempArray;
    int noOfRecords;
    UIActivityIndicatorView *indicator;
    NSArray *json;
}
@property (strong, nonatomic) NSString *pageId;
@property (weak, nonatomic) IBOutlet UITableView *tableData;

@end
