//
//  AppDelegate.h
//  eReaderDemo
//
//  Created by mohamed Alaa El-Din on 10/11/13.
//  Copyright (c) 2013 mohamed Alaa El-Din. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DashboardViewController.h"
#import <FacebookSDK/FacebookSDK.h>
#import "ReaderViewController.h"
@class DashboardViewController;

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;
@property (nonatomic,strong) DashboardViewController *dashboard;
@property (strong, nonatomic) UINavigationController *navigation;

- (void)openSession;
@end
