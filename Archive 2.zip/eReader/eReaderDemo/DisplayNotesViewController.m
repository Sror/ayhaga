//
//  DisplayNotesViewController.m
//  eReaderDemo
//
//  Created by Mohamed Alaa El-Din on 10/22/13.
//  Copyright (c) 2013 mohamed Alaa El-Din. All rights reserved.
//

#import "DisplayNotesViewController.h"

@interface DisplayNotesViewController ()

@end

@implementation DisplayNotesViewController
@synthesize pageId,noteWebView,container, url;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
     noteWebView.delegate = self;
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone)
        indicator = [[UIActivityIndicatorView alloc] initWithFrame:CGRectMake(self.view.frame.size.width/2 -30 , self.view.frame.size.height/2, 50, 50)];
    else
        indicator = [[UIActivityIndicatorView alloc] initWithFrame:CGRectMake(330, 500, 100, 100)];
    
    indicator.color = [UIColor blackColor];
    [self.view addSubview:indicator];
    [indicator startAnimating];
    
  /*  NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    NSString *accessToken = [defaults objectForKey:@"FBAccessTokenKey"];
  //  NSString *urlString = [NSString stringWithFormat:@"https://graph.facebook.com/%@?access_token=%@", pageId,[accessToken stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding] ];
    NSString *urlString = [NSString stringWithFormat:@"https://ajax.googleapis.com/ajax/services/feed/find?v=1.0&q=بلال فضل"];
    NSURL *url = [NSURL URLWithString:urlString];
    ASIHTTPRequest *request = [ASIHTTPRequest requestWithURL:url];
    [request setDidFinishSelector:@selector(loadNotes:)];
    
    [request setDelegate:self];
    [request startAsynchronous];
    */
    noteWebView.delegate = self;
    noteWebView.scalesPageToFit   = YES;
    NSURL *urlStr            = [NSURL URLWithString:url];
    NSURLRequest *request = [NSURLRequest requestWithURL:urlStr];
    [noteWebView loadRequest:request];

}

- (void)webViewDidFinishLoad:(UIWebView *)aWebView {
 
    //[container setContentSize:CGSizeMake(0, aWebView.bounds.size.height +100)];
    
}

- (void)loadNotes:(ASIHTTPRequest *)request
{
    
    NSString *responseString = [request responseString];
    
    NSData *JSONContent = [responseString dataUsingEncoding:NSUTF8StringEncoding];
    NSError *error;
    NSArray *json = [NSJSONSerialization JSONObjectWithData:JSONContent
                                           options:kNilOptions error:&error];
    
    CGRect rect;
    if([ [ [ UIDevice currentDevice ] model ] isEqualToString: @"iPhone" ])
        rect = CGRectMake(self.view.frame.origin.x, self.view.frame.origin.y +64, self.view.frame.size.width, self.view.frame.size.height);
    else
        rect = CGRectMake(self.view.frame.origin.x, self.view.frame.origin.y +64, 768, 1024);
    
   
    
    
    
    [self.noteWebView loadHTMLString:[json valueForKey:@"message"] baseURL:nil];

    
    [indicator stopAnimating];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

@end
