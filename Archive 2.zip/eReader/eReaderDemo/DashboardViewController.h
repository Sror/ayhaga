//
//  DashboardViewController.h
//  eReaderDemo
//
//  Created by mohamed Alaa El-Din on 10/11/13.
//  Copyright (c) 2013 mohamed Alaa El-Din. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

@interface DashboardViewController : UIViewController
@property (weak, nonatomic) IBOutlet UIButton *facebookLogin;

- (IBAction)facebookLogin:(id)sender;
- (void)loginFailed;
@end
