//
//  DisplayReader.h
//  eReaderDemo
//
//  Created by mohamed Alaa El-Din on 10/22/13.
//  Copyright (c) 2013 mohamed Alaa El-Din. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PagesModel.h"
#import "DbAccessor.h"
#import "PostsModel.h"
@interface DisplayReader : UIViewController <UITextFieldDelegate,UITableViewDataSource,UITableViewDelegate,UISearchBarDelegate>
{
    NSString *indexPathNo;
    UIActivityIndicatorView *indicator;
    NSArray *json;
    int noOfRecords;
    NSMutableArray *tempArray,*correctUrls,*msgsArr,*namesArr;
    NSString *queryStr;
    DbAccessor *db;
    int totalBytesReceived;
}
- (IBAction)search:(id)sender;

@property (weak, nonatomic) IBOutlet UITableView *tableData;
@end
