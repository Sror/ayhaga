//
//  ReaderViewController.h
//  eReaderDemo
//
//  Created by mohamed Alaa El-Din on 10/11/13.
//  Copyright (c) 2013 mohamed Alaa El-Din. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "UIView+UIView_Gradient.h"
@interface ReaderViewController : UIViewController <UITableViewDataSource,UITableViewDelegate>
{
    NSMutableArray *graphApiTypes;
}
@property (weak, nonatomic) IBOutlet UITableView *tableData;

@end
