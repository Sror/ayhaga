//
//  PostsModel.h
//  eReaderDemo
//
//  Created by Mohamed Alaa El-Din on 10/31/13.
//  Copyright (c) 2013 mohamed Alaa El-Din. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface PostsModel : NSObject
@property (nonatomic,strong) NSString *msg;
@property (nonatomic,strong) NSString *link;
@property (nonatomic,strong) NSString *name;

@end
