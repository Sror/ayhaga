//
//  ReaderViewController.m
//  eReaderDemo
//
//  Created by mohamed Alaa El-Din on 10/11/13.
//  Copyright (c) 2013 mohamed Alaa El-Din. All rights reserved.
//

#import "ReaderViewController.h"

#import "AppDelegate.h"
#import "DisplayReader.h"
#import "DashboardViewController.h"
@interface ReaderViewController ()

@end

@implementation ReaderViewController
@synthesize tableData;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}
-(IBAction)logout:(id)sender
{
     [FBSession.activeSession closeAndClearTokenInformation];
    DashboardViewController *dashboard = [[DashboardViewController alloc] init];
    [self.navigationController pushViewController:dashboard animated:YES];
}
- (void)viewDidLoad
{
    [super viewDidLoad];
  
    
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"log out" style:UIBarButtonItemStylePlain target:self action:@selector(logout:)];

    graphApiTypes = [[NSMutableArray alloc] initWithObjects:@"search for all  posts",@"search for users",@"search for pages" ,nil];

}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSString *CellIdentifier = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    
    if(cell == nil)
    {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
        [cell setBackgroundColor:[UIColor clearColor]];
        CGRect backgroundViewFrame = cell.contentView.frame;
        backgroundViewFrame.size.height = 75;
        cell.backgroundView = [[UIView alloc] initWithFrame:backgroundViewFrame];
        [cell.backgroundView addLinearUniformGradient:[NSArray arrayWithObjects:
                                                       (id)[[UIColor whiteColor] CGColor],
                                                       (id)[[UIColor colorWithRed:0x87/255.0f green:0xce/255.0f blue:0xeb/255.0f alpha:1] CGColor], nil]];

    }
    
    // Configure the cell...
    
    
    cell.textLabel.text = [graphApiTypes objectAtIndex:indexPath.row];
    
    return cell;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 75;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return graphApiTypes.count;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
     NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    switch (indexPath.row) {
        case 0:
            [defaults setObject:@"1" forKey:@"indexPath"];
            break;
        case 1:
            [defaults setObject:@"2" forKey:@"indexPath"];
            break;
        case 2:
            [defaults setObject:@"3" forKey:@"indexPath"];
            break;
        default:
            break;
    }
    [defaults synchronize];
    DisplayReader *displayReader = [[DisplayReader alloc] init];
    [self.navigationController pushViewController:displayReader animated:YES];
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
