//
//  DisplayObject.m
//  eReaderDemo
//
//  Created by Mohamed Alaa El-Din on 10/22/13.
//  Copyright (c) 2013 mohamed Alaa El-Din. All rights reserved.
//

#import "DisplayObject.h"
#import "ASIHTTPRequest.h"
#import "ASIFormDataRequest.h"
#import "NotesViewController.h"
#import "PostsView.h"
@interface DisplayObject ()

@end

@implementation DisplayObject
@synthesize data,pageId;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone)
        indicator = [[UIActivityIndicatorView alloc] initWithFrame:CGRectMake(self.view.frame.size.width/2 -30 , self.view.frame.size.height/2, 50, 50)];
    else
        indicator = [[UIActivityIndicatorView alloc] initWithFrame:CGRectMake(330, 500, 100, 100)];
    
    indicator.color = [UIColor blackColor];
    [self.view addSubview:indicator];
    [indicator startAnimating];


    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    NSString *indexPathNo = [defaults objectForKey:@"indexPath"];
    
    CGRect rect;
    if([ [ [ UIDevice currentDevice ] model ] isEqualToString: @"iPhone" ])
        rect = CGRectMake(self.view.frame.origin.x, self.view.frame.origin.y +130, self.view.frame.size.width, self.view.frame.size.height);
    else
        rect = CGRectMake(self.view.frame.origin.x, self.view.frame.origin.y+80, 768, 1024);

    if([indexPathNo isEqualToString:@"1"])
    {
        UIScrollView *container = [[UIScrollView alloc] initWithFrame:rect];
        [self.view addSubview:container];

        UILabel *post = [[UILabel alloc] initWithFrame:CGRectMake(50, 20, self.view.frame.size.width -50, 500)];
        post.text = [data valueForKey:@"message"];
        post.lineBreakMode = NSLineBreakByWordWrapping;
        post.numberOfLines = 0;
        [post sizeToFit];
        post.backgroundColor = [UIColor clearColor];
        [container addSubview:post];
        [indicator stopAnimating];
    
        [container setContentSize:CGSizeMake(0, post.bounds.size.height +160)];
    }
    else if([indexPathNo isEqualToString:@"2"])
    {
        NSString *urlString = [NSString stringWithFormat:@"https://graph.facebook.com/%@", [data valueForKey:@"id"]];
        
        NSURL *url = [NSURL URLWithString:urlString];
        ASIHTTPRequest *request = [ASIHTTPRequest requestWithURL:url];
        [request setDidFinishSelector:@selector(drawUser:)];
        
        [request setDelegate:self];
        [request startAsynchronous];
    }
    else if([indexPathNo isEqualToString:@"3"])
    {
        //getNotes.hidden = NO;
        
        // self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"Get Notes" style:UIBarButtonItemStylePlain target:self action:@selector(getNotes:)];
         self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"Get Posts" style:UIBarButtonItemStylePlain target:self action:@selector(getPosts:)];
      
        NSString *urlString = [NSString stringWithFormat:@"https://graph.facebook.com/%@", pageId];
        NSURL *url = [NSURL URLWithString:urlString];
        ASIHTTPRequest *request = [ASIHTTPRequest requestWithURL:url];
        [request setDidFinishSelector:@selector(drawPage:)];
        
        [request setDelegate:self];
        [request startAsynchronous];
    }
}

- (void)drawUser:(ASIHTTPRequest *)request
{
    NSString *responseString = [request responseString];
    
    NSData *JSONContent = [responseString dataUsingEncoding:NSUTF8StringEncoding];
    NSError *error;
    json = [NSJSONSerialization JSONObjectWithData:JSONContent
                                           options:kNilOptions error:&error];
    
    CGRect rect;
    if([ [ [ UIDevice currentDevice ] model ] isEqualToString: @"iPhone" ])
        rect = CGRectMake(self.view.frame.origin.x, self.view.frame.origin.y +130, self.view.frame.size.width, self.view.frame.size.height);
    else
        rect = CGRectMake(self.view.frame.origin.x, self.view.frame.origin.y, 768, 1024);
    
    UIScrollView *container = [[UIScrollView alloc] initWithFrame:rect];
    [self.view addSubview:container];
    
    UILabel *post = [[UILabel alloc] initWithFrame:CGRectMake(50, 80, self.view.frame.size.width -50, 500)];
    post.text = [NSString stringWithFormat:@"%@",json];
    post.lineBreakMode = NSLineBreakByWordWrapping;
    post.numberOfLines = 0;
    [post sizeToFit];
    post.backgroundColor = [UIColor clearColor];
    [container addSubview:post];
    
    [container setContentSize:CGSizeMake(0, post.bounds.size.height +60)];
    
    [indicator stopAnimating];
}

- (void)drawPage:(ASIHTTPRequest *)request
{
    NSString *responseString = [request responseString];
    
    NSData *JSONContent = [responseString dataUsingEncoding:NSUTF8StringEncoding];
    NSError *error;
    json = [NSJSONSerialization JSONObjectWithData:JSONContent
                                                    options:kNilOptions error:&error];
    
    
    CGRect rect;
    if([ [ [ UIDevice currentDevice ] model ] isEqualToString: @"iPhone" ])
        rect = CGRectMake(self.view.frame.origin.x, self.view.frame.origin.y +64, self.view.frame.size.width, self.view.frame.size.height);
    else
        rect = CGRectMake(self.view.frame.origin.x, self.view.frame.origin.y +64, 768, 1024);
    
    UIScrollView *container = [[UIScrollView alloc] initWithFrame:rect];
    [self.view addSubview:container];
    
    UILabel *post = [[UILabel alloc] initWithFrame:CGRectMake(30, 80, self.view.frame.size.width -50, 500)];
    post.text = [NSString stringWithFormat:@"%@",json];
    post.lineBreakMode = NSLineBreakByWordWrapping;
    post.numberOfLines = 0;
    [post sizeToFit];
    post.backgroundColor = [UIColor clearColor];
    [container addSubview:post];
    
    [container setContentSize:CGSizeMake(0, post.bounds.size.height +260)];
    [indicator stopAnimating];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)getNotes:(id)sender {
    NotesViewController *notesviewController = [[NotesViewController alloc] init];
    notesviewController.pageId = [json valueForKey:@"id"];
    [self.navigationController pushViewController:notesviewController animated:YES];
}

- (IBAction)getPosts:(id)sender {
    PostsView *postsView = [[PostsView alloc] init];
    postsView.pageId = [json valueForKey:@"id"];
    [self.navigationController pushViewController:postsView animated:YES];
}
@end
