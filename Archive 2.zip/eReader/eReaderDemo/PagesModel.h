//
//  PagesModel.h
//  eReaderDemo
//
//  Created by Mohamed Alaa El-Din on 10/30/13.
//  Copyright (c) 2013 mohamed Alaa El-Din. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface PagesModel : NSObject
@property (nonatomic) int rId;
@property (nonatomic,strong) NSString *pageId;
@property (nonatomic) int pageLikes;
@end
