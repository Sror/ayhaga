//
//  DisplayReader.m
//  eReaderDemo
//
//  Created by mohamed Alaa El-Din on 10/22/13.
//  Copyright (c) 2013 mohamed Alaa El-Din. All rights reserved.
//

#import "DisplayReader.h"
#import "ASIHTTPRequest.h"
#import "ASIFormDataRequest.h"
#import "DisplayObject.h"
#import "DisplayNotesViewController.h"
@interface DisplayReader ()

@end

@implementation DisplayReader
@synthesize  tableData;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];

}


-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSString *CellIdentifier = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    
    if(cell == nil)
    {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:CellIdentifier];
    }
    // Configure the cell...
    
    cell.backgroundColor = [UIColor clearColor];

    cell.textLabel.text = [namesArr objectAtIndex:indexPath.row] ;
    
   
    cell.detailTextLabel.text = [msgsArr objectAtIndex:indexPath.row];
    
    
    
    return cell;}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 100;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return correctUrls.count;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    DisplayObject *displayObject = [[DisplayObject alloc] init];
     DisplayNotesViewController *displayNotesViewController = [[DisplayNotesViewController alloc] init];
    if([indexPathNo isEqualToString:@"3"])
    {
         displayNotesViewController.url = [correctUrls objectAtIndex:indexPath.row] ;
         [self.navigationController pushViewController:displayNotesViewController animated:YES];
       // NSLog(@"%@",[tempArray objectAtIndex:indexPath.row]);
    }
    else
    {
        displayObject.data = [[json valueForKey:@"data"] objectAtIndex:indexPath.row];
    [self.navigationController pushViewController:displayObject animated:YES];
    }
    
}



-(void)search
{
    
    correctUrls= [[NSMutableArray alloc] init];
     msgsArr= [[NSMutableArray alloc] init];
     namesArr= [[NSMutableArray alloc] init];
    
    [correctUrls removeAllObjects];
     [msgsArr removeAllObjects];
     [namesArr removeAllObjects];
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone)
        indicator = [[UIActivityIndicatorView alloc] initWithFrame:CGRectMake(self.view.frame.size.width/2 -30 , self.view.frame.size.height/2, 50, 50)];
    else
         indicator = [[UIActivityIndicatorView alloc] initWithFrame:CGRectMake(330, 500, 100, 100)];
    
    indicator.color = [UIColor blackColor];
    [self.view addSubview:indicator];
    [indicator startAnimating];
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    
    NSString *accessToken = [defaults objectForKey:@"FBAccessTokenKey"];
    
    NSString *urlString;
    if([indexPathNo isEqualToString:@"1"])
    {
       urlString = [NSString stringWithFormat:@"https://ajax.googleapis.com/ajax/services/feed/find?v=1.0&q=%@",[queryStr stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]];
    }
    
    else if([indexPathNo isEqualToString:@"2"])
        urlString = [NSString stringWithFormat:@"https://graph.facebook.com/search?q=%@&type=user&access_token=%@",
                     [queryStr stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding],[accessToken stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]];
    
    else if([indexPathNo isEqualToString:@"3"])
        urlString = [NSString stringWithFormat:@"https://graph.facebook.com/search?fields=likes&q=%@&type=page&access_token=%@",
                     [queryStr stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding],[accessToken stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]];
    
    NSURL *url = [NSURL URLWithString:urlString];
    ASIHTTPRequest *request = [ASIHTTPRequest requestWithURL:url];
    [request setDidFinishSelector:@selector(searchFinished:)];
    [request setDelegate:self];
    [request startAsynchronous];
}

- (void)searchFinished:(ASIHTTPRequest *)request
{
    db = [[DbAccessor alloc] init];
    
    NSString *responseString = [request responseString];
    
    NSData *JSONContent = [responseString dataUsingEncoding:NSUTF8StringEncoding];
    NSError *error;
    json = [NSJSONSerialization JSONObjectWithData:JSONContent
                                           options:kNilOptions error:&error];
    
    
    
    
    
    noOfRecords = [[json valueForKey:@"data"] count];
    
    tempArray = [[NSMutableArray alloc] init];
    
    if([indexPathNo isEqualToString:@"3"])
    {
        for(int i = 0 ; i < noOfRecords ; i++)
        {
            [db savePagesLikes:[[[json valueForKey:@"data"] objectAtIndex:i] valueForKey:@"id"] :[[[[json valueForKey:@"data"] objectAtIndex:i] valueForKey:@"likes"] integerValue]];
           // [tempArray addObject:[[[json valueForKey:@"data"] objectAtIndex:i] valueForKey:@"likes"]];
        }
       
        NSMutableArray *arr = [db getPagesSorted];
        
        ///remove
        [db deletePages];
        int count = 1;
        for(PagesModel *page in arr)
        {
            if(count<=5)
                [tempArray addObject:page.pageId];
            count++;
        }
        
        for(int i = 0 ;i < 5 ; i++)
        {
        NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
        NSString *accessToken = [defaults objectForKey:@"FBAccessTokenKey"];
        NSString *urlString = [NSString stringWithFormat:@"https://graph.facebook.com/%@/posts?access_token=%@", [tempArray objectAtIndex:i],[accessToken stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding] ];
            //fields=link
        NSURL *url = [NSURL URLWithString:urlString];
        ASIHTTPRequest *request = [ASIHTTPRequest requestWithURL:url];
        [request setBytesReceivedBlock:^(unsigned long long length, unsigned long long total) {
        totalBytesReceived += length;
        NSLog(@"bytes = %i  , total = %lli",totalBytesReceived, total);
            if (totalBytesReceived >= 1000)
            {
            }
           
        }];
            
        [request setDelegate:self];
        [request startAsynchronous];
        }
      
    }
    

    if([indexPathNo isEqualToString:@"1"])
    {
        for(int i = 1; i <= noOfRecords ; i++)
            [tempArray addObject:[NSString stringWithFormat:@"post %d",i]];
    }
    else if([indexPathNo isEqualToString:@"2"])
    {
        for(int i = 0; i < noOfRecords ; i++)
            [tempArray addObject:[[[json valueForKey:@"data"] valueForKey:@"name"] objectAtIndex:i]];

    }
      
   // [tableData reloadData];
   // [indicator stopAnimating];
    
    if(noOfRecords == 0)
        [[[UIAlertView alloc] initWithTitle:@"Not found" message:@"Result not found!" delegate:nil cancelButtonTitle:@"ok" otherButtonTitles:Nil, nil] show];
}

- (void)loadPosts:(ASIHTTPRequest *)request
{
     db = [[DbAccessor alloc] init];
    NSString *responseString = [request responseString];
    
    NSData *JSONContent = [responseString dataUsingEncoding:NSUTF8StringEncoding];
    NSError *error;
    json = [NSJSONSerialization JSONObjectWithData:JSONContent
                                           options:kNilOptions error:&error];
    noOfRecords = [[json valueForKey:@"data"] count];
    
    
    if(noOfRecords == 0)
    {
        [[[UIAlertView alloc] initWithTitle:@"Not found" message:@"Result not found!" delegate:nil cancelButtonTitle:@"ok" otherButtonTitles:Nil, nil] show];
        [indicator stopAnimating];
        return;
    }
    
    [tempArray removeAllObjects];
    
    
    
    NSString *msg, *link,*name;
    for(int i = 0; i < noOfRecords ; i++)
    {
        msg = [[[json valueForKey:@"data"] objectAtIndex:i] valueForKey:@"message"];
        link = [[[json valueForKey:@"data"] objectAtIndex:i] valueForKey:@"link"];
        name = [[[json valueForKey:@"data"] objectAtIndex:i] valueForKey:@"name"];
        if(!link)
            link = @"";
        if (!msg)
            msg = @"";
        if (!name)
            name = @"";
        
        [db savePosts:msg :link :name];
            
    }
   
    NSMutableArray *trustedURls = [db getUrls];
    
    NSMutableArray *dbResults = [db getPosts];
    [db deletePosted];
    
    for(PostsModel *post in dbResults)
    {
        NSLog(@"%@",post.link);
        if([post.link length] == 0)
            continue;
        NSString *tempStr = [[post.link componentsSeparatedByString:@"/"] objectAtIndex:2];
        for (int j = 0 ; j < trustedURls.count; j++)
        {
            NSString *trustStr = [[[trustedURls objectAtIndex:j] componentsSeparatedByString:@"/"] objectAtIndex:2];
            if([trustStr isEqualToString:tempStr])
            {
                [correctUrls addObject:post.link];
                [msgsArr addObject:post.msg];
                [namesArr addObject:post.name];
            }
        }
    }
    
  
    [tableData reloadData];
    [indicator stopAnimating];
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)search:(id)sender {
    
}

- (void)searchBarSearchButtonClicked:(UISearchBar *)searchBar
{
    queryStr = searchBar.text;
    [searchBar resignFirstResponder];

    if(searchBar.text.length == 0)
    {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"warning" message:@"Please enter the keyword!" delegate:self cancelButtonTitle:@"Try again" otherButtonTitles:nil, nil];
        [alert show];
    }
    else
    {
        NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
        
        indexPathNo = [defaults objectForKey:@"indexPath"];
        if([indexPathNo isEqualToString:@"1"]  || [indexPathNo isEqualToString:@"2"] || [indexPathNo isEqualToString:@"3"])
        {
            [self search];
        }
    }
}
@end
