//
//  PagesModel.m
//  eReaderDemo
//
//  Created by Mohamed Alaa El-Din on 10/30/13.
//  Copyright (c) 2013 mohamed Alaa El-Din. All rights reserved.
//

#import "PagesModel.h"

@implementation PagesModel
@synthesize rId,pageLikes,pageId;
@end
