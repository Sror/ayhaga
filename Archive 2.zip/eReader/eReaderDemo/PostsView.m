//
//  PostsView.m
//  eReaderDemo
//
//  Created by Mohamed Alaa El-Din on 10/29/13.
//  Copyright (c) 2013 mohamed Alaa El-Din. All rights reserved.
//

#import "PostsView.h"

@interface PostsView ()

@end

@implementation PostsView
@synthesize tableData,pageId;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    tempArray= [[NSMutableArray alloc] init];
    correctUrls= [[NSMutableArray alloc] init];
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone)
        indicator = [[UIActivityIndicatorView alloc] initWithFrame:CGRectMake(self.view.frame.size.width/2 -30 , self.view.frame.size.height/2, 50, 50)];
    else
        indicator = [[UIActivityIndicatorView alloc] initWithFrame:CGRectMake(330, 500, 100, 100)];
    
    indicator.color = [UIColor blackColor];
    [self.view addSubview:indicator];
    [indicator startAnimating];
    
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    NSString *accessToken = [defaults objectForKey:@"FBAccessTokenKey"];
    NSString *urlString = [NSString stringWithFormat:@"https://graph.facebook.com/%@/posts?fields=link&access_token=%@", pageId,[accessToken stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding] ];
    NSURL *url = [NSURL URLWithString:urlString];
    ASIHTTPRequest *request = [ASIHTTPRequest requestWithURL:url];
    [request setDidFinishSelector:@selector(loadPosts:)];
    
    [request setDelegate:self];
    [request startAsynchronous];
    
    
    
}

- (void)loadPosts:(ASIHTTPRequest *)request
{
    NSString *responseString = [request responseString];
    
    NSData *JSONContent = [responseString dataUsingEncoding:NSUTF8StringEncoding];
    NSError *error;
    json = [NSJSONSerialization JSONObjectWithData:JSONContent
                                           options:kNilOptions error:&error];
    noOfRecords = [[json valueForKey:@"data"] count];
    
    if(noOfRecords == 0)
    {
        [[[UIAlertView alloc] initWithTitle:@"Not found" message:@"Result not found!" delegate:nil cancelButtonTitle:@"ok" otherButtonTitles:Nil, nil] show];
        [indicator stopAnimating];
        return;
    }

    
    
    
    for(int i = 0; i < noOfRecords ; i++)
    {
        NSString *value = [[[json valueForKey:@"data"] objectAtIndex:i] valueForKey:@"link"];
        if (value)
            [tempArray addObject:[[[json valueForKey:@"data"] objectAtIndex:i] valueForKey:@"link"] ];
    }
    db = [[DbAccessor alloc] init];
    NSMutableArray *trustedURls = [db getUrls];
    
    
    for(int i = 0 ; i < tempArray.count ; i++)
    {
         NSLog(@"%@",[tempArray objectAtIndex:i]);
        NSString *tempStr = [[[tempArray objectAtIndex:i] componentsSeparatedByString:@"/"] objectAtIndex:2];
        for (int j = 0 ; j < trustedURls.count; j++)
        {
           
            NSString *trustStr = [[[trustedURls objectAtIndex:j] componentsSeparatedByString:@"/"] objectAtIndex:2];
            if([trustStr isEqualToString:tempStr])
            {
                [correctUrls addObject:[tempArray objectAtIndex:i]];
                NSLog(@"%@",[tempArray objectAtIndex:i]);
            }
        }
    }
    
    if(correctUrls.count == 0)
    {
        [[[UIAlertView alloc] initWithTitle:@"Not found" message:@"Trusted results not found!" delegate:nil cancelButtonTitle:@"ok" otherButtonTitles:Nil, nil] show];
    }
    [tableData reloadData];
    [indicator stopAnimating];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSString *CellIdentifier = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    
    if(cell == nil)
    {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
    }
    // Configure the cell...
    cell.textLabel.text = [correctUrls objectAtIndex:indexPath.row];
    
    return cell;}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 75;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return correctUrls.count;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
   /* DisplayNotesViewController *displayObject = [[DisplayNotesViewController alloc] init];
    displayObject.pageId = [[[json valueForKey:@"data"] valueForKey:@"id"] objectAtIndex:indexPath.row];
    
    [self.navigationController pushViewController:displayObject animated:YES];*/
}




@end
