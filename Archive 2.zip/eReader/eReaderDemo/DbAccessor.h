//
//  DbAccessor.h
//  rssDemo
//
//  Created by Mohamed Alaa El-Din on 10/29/13.
//  Copyright (c) 2013 Mohamed Alaa El-Din. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <sqlite3.h>
#import "PagesModel.h"
#import "PostsModel.h"
@interface DbAccessor : NSObject
{
    NSString  *databasePath;
    sqlite3   *contactDB;
    sqlite3* database;
}

- (NSMutableArray *) getUrls;

-(BOOL)savePagesLikes:(NSString *)pageId :(int)pageLikes;
-(NSMutableArray *) getPagesSorted;
-(BOOL) deletePages;

-(BOOL)savePosts:(NSString *)msg :(NSString *)link :(NSString *)name;
- (NSMutableArray *) getPosts;
-(BOOL) deletePosted;

@end
