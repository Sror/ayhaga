//
//  ReaderView.m
//  GoogleNews
//
//  Created by Mohamed Alaa El-Din on 10/27/13.
//  Copyright (c) 2013 Mohamed Alaa El-Din. All rights reserved.
//

#import "ReaderView.h"

@interface ReaderView ()

@end

@implementation ReaderView
@synthesize container,data;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

-(void)webViewDidFinishLoad:(UIWebView *)webView
{
    [indicator stopAnimating];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone)
        indicator   = [[UIActivityIndicatorView alloc] initWithFrame:CGRectMake(self.view.frame.size.width/2 -30 , self.view.frame.size.height/2, 50, 50)];
    else
        indicator   = [[UIActivityIndicatorView alloc] initWithFrame:CGRectMake(330, 500, 100, 100)];
    
    indicator.color = [UIColor blackColor];
    [self.view addSubview:indicator];
    [indicator startAnimating];

    
    UIWebView *web        = [[UIWebView alloc] initWithFrame:CGRectMake(0, 0,  768,  1024)];
    web.delegate          = self;
    web.scalesPageToFit   = YES;
    NSString *urlStr      = [data  valueForKey:@"signedRedirectUrl"] ;
    NSURL *url            = [NSURL URLWithString:urlStr];
    NSURLRequest *request = [NSURLRequest requestWithURL:url];
    
    [web loadRequest:request];
    [self.container addSubview:web];
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
