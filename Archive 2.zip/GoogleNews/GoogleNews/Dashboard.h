//
//  Dashboard.h
//  GoogleNews
//
//  Created by Mohamed Alaa El-Din on 10/24/13.
//  Copyright (c) 2013 Mohamed Alaa El-Din. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Dashboard.h"
#import "ASIHTTPRequest.h"
#import "ASIFormDataRequest.h"
#import "TableCell.h"

@class Dashboard;
@interface Dashboard : UIViewController<UISearchBarDelegate,UITableViewDataSource,UITableViewDelegate>
{
    UIActivityIndicatorView *indicator;
    NSString *queryStr;
    NSMutableArray *data;
    IBOutlet TableCell *tableCell;
}
@property (nonatomic,strong) Dashboard *dashboard;
@property (strong, nonatomic) UINavigationController *navigation;
@property (weak, nonatomic) IBOutlet UISearchBar *searchbar;
@property (weak, nonatomic) IBOutlet UITableView *tableData;

@property (weak, nonatomic) IBOutlet UIWebView *myWeb;


@end
