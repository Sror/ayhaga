//
//  Dashboard.m
//  GoogleNews
//
//  Created by Mohamed Alaa El-Din on 10/24/13.
//  Copyright (c) 2013 Mohamed Alaa El-Din. All rights reserved.
//

#import "Dashboard.h"
#import "ReaderView.h"

@interface Dashboard ()

@end

@implementation Dashboard
@synthesize searchbar,tableData, myWeb;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    searchbar.delegate = self;
    
    
}

-(void)search
{
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone)
        indicator = [[UIActivityIndicatorView alloc] initWithFrame:CGRectMake(self.view.frame.size.width/2 -30 , self.view.frame.size.height/2, 50, 50)];
    else
        indicator = [[UIActivityIndicatorView alloc] initWithFrame:CGRectMake(330, 500, 100, 100)];
    
    indicator.color = [UIColor blackColor];
    [self.view addSubview:indicator];
    [indicator startAnimating];
    //NSString *urlString = [NSString stringWithFormat:@"https://ajax.googleapis.com/ajax/services/search/news?v=1.0&q=%@",[queryStr stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]];
    
    NSString *urlString = @"https://www.google.com/search?q=مقال باسم يوسف";
    
    
    NSURL *url = [NSURL URLWithString:urlString];
    ASIHTTPRequest *request = [ASIHTTPRequest requestWithURL:url];
    [request setDidFinishSelector:@selector(searchFinished:)];
    
    [request setDelegate:self];
    [request startAsynchronous];
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
   [[NSBundle mainBundle] loadNibNamed:@"TableCell" owner:self options:nil];

    NSURL * imageURL   = [NSURL URLWithString:[[[data objectAtIndex:indexPath.row] valueForKey:@"image"] valueForKey:@"url"]];
    NSData * imageData = [NSData dataWithContentsOfURL:imageURL];
    UIImage * image    = [UIImage imageWithData:imageData];

    tableCell.img.image             = image;
    tableCell.title.text            = [[data objectAtIndex:indexPath.row] valueForKey:@"title"];
    tableCell.publisher.text        = [[data objectAtIndex:indexPath.row] valueForKey:@"publisher"];
    tableCell.date.text             = [[data objectAtIndex:indexPath.row] valueForKey:@"publishedDate"];
    tableCell.content.text          = [[data objectAtIndex:indexPath.row] valueForKey:@"content"];
    tableCell.content.lineBreakMode = NSLineBreakByWordWrapping;
    tableCell.content.numberOfLines = 0;
    [tableCell.content sizeToFit];
    
    return tableCell;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 300;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return data.count;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    ReaderView *readerView = [[ReaderView alloc] init];
    readerView.data = [data objectAtIndex:indexPath.row];
    [self.navigationController pushViewController:readerView animated:YES];
}

- (void)searchFinished:(ASIHTTPRequest *)request
{
    NSString *responseString = [request responseString];
    
    // [self.myWeb loadHTMLString:responseString baseURL:nil];
    
    NSLog(@"res = %@",responseString);
    NSData *JSONContent = [responseString dataUsingEncoding:NSUTF8StringEncoding];
    NSError *error;
    NSArray *json = [NSJSONSerialization JSONObjectWithData:JSONContent
                                           options:kNilOptions error:&error];
    
    data = [[json valueForKey:@"responseData"] valueForKey:@"results"];

    [tableData reloadData];

    [indicator stopAnimating];
}

- (void)searchBarSearchButtonClicked:(UISearchBar *)searchBar
{
    queryStr = searchBar.text;
    [searchBar resignFirstResponder];
    if(searchBar.text.length == 0)
       [[[UIAlertView alloc] initWithTitle:@"warning" message:@"Please enter the keyword!" delegate:self cancelButtonTitle:@"Try again" otherButtonTitles:nil, nil] show];
    else
        [self search];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

@end
