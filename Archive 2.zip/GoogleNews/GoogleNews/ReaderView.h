//
//  ReaderView.h
//  GoogleNews
//
//  Created by Mohamed Alaa El-Din on 10/27/13.
//  Copyright (c) 2013 Mohamed Alaa El-Din. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ReaderView : UIViewController <UIWebViewDelegate>
{
    UIActivityIndicatorView *indicator;
}
@property (weak, nonatomic) IBOutlet UIScrollView *container;
@property (strong, nonatomic)  NSMutableArray *data;

@end
