//
//  TableCell.m
//  GoogleNews
//
//  Created by Mohamed Alaa El-Din on 10/27/13.
//  Copyright (c) 2013 Mohamed Alaa El-Din. All rights reserved.
//

#import "TableCell.h"

@implementation TableCell
@synthesize img,title,publisher,date,content;
- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];
}

@end
