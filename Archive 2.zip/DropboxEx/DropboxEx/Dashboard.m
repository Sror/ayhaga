//
//  Dashboard.m
//  DropboxEx
//
//  Created by Mohamed Alaa El-Din on 11/5/13.
//  Copyright (c) 2013 Mohamed Alaa El-Din. All rights reserved.
//

#import "Dashboard.h"
#import "SecondView.h"
#import "ASIHTTPRequest.h"
#import "ASIFormDataRequest.h"

@interface Dashboard ()

@end

@implementation Dashboard
@synthesize restClient,tableData;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    if ([[DBSession sharedSession] isLinked])
    {
         self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"logout" style:UIBarButtonItemStylePlain target:self action:@selector(authenticate:)];
        [[self restClient] loadMetadata:@"/"];
    }
    else
         self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"login" style:UIBarButtonItemStylePlain target:self action:@selector(authenticate:)];

    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(uploadToDropbox) name:@"uploadToDropbox" object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(failedToLogin) name:@"failedToLogin" object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(succeedToLogin) name:@"succeedToLogin" object:nil];
   
    self.title = @"Dropbox";
    // Do any additional setup after loading the view from its nib.
}


- (void)restClient:(DBRestClient*)client loadedFile:(NSString*)localPath
       contentType:(NSString*)contentType metadata:(DBMetadata*)metadata {
    
    NSLog(@"File loaded into path: %@", localPath);
}

- (void)restClient:(DBRestClient*)client loadFileFailedWithError:(NSError*)error {
    NSLog(@"There was an error loading the file - %@", error);
}

//metadata deleget
- (void)restClient:(DBRestClient *)client loadedMetadata:(DBMetadata *)metadata {
    if (metadata.isDirectory) {
        files = [[NSMutableArray alloc] init];
        for (DBMetadata *file in metadata.contents) {
            [files addObject:file.filename];
        }
       // [self downloadFromDropbox];
        [tableData reloadData];
    }
}

- (void)restClient:(DBRestClient *)client
loadMetadataFailedWithError:(NSError *)error {
    
    NSLog(@"Error loading metadata: %@", error);
}

-(void)uploadToDropbox
{
   /* NSString *localPath = [[NSBundle mainBundle] pathForResource:@"facebookSDK_PDF" ofType:@"pdf"];
    NSString *filename = @"facebookSDK_PDF.pdf";
    NSString *destDir = @"/";
    [[self restClient] uploadFile:filename toPath:destDir
                    withParentRev:nil fromPath:localPath];*/
    [self getDirctLinkOfFile];
}

-(void)downloadFromDropbox
{
    NSString *DropBoxpath = @"/working-draft.txt";
    NSString *devicepath = [[NSBundle mainBundle] pathForResource:@"fileData" ofType:@"txt"];
     [[self restClient] loadFile:DropBoxpath intoPath:devicepath];

}

-(void)getDirctLinkOfFile
{

    [[self restClient] loadStreamableURLForFile:@"/facebookSDK_PDF.pdf"];
}

- (void)restClient:(DBRestClient*)restClient loadStreamableURLFailedWithError:(NSError *)error
{
     NSLog(@"%@", [error localizedDescription]);
}

-(void)restClient:(DBRestClient *)restClient loadedStreamableURL:(NSURL *)url forFile:(NSString *)path
{
    NSLog(@"%@",[url absoluteURL]);
    
    NSString *downloadLink = [NSString stringWithFormat:@"%@",[url absoluteURL]];
    ASIHTTPRequest *request;
    UIProgressView *theProgressView;
    progressAlert = [[UIAlertView alloc] initWithTitle:nil  message: @"Please wait..." delegate: self cancelButtonTitle: nil otherButtonTitles: nil];
    theProgressView = [[UIProgressView alloc] initWithFrame:CGRectMake(20.0f, 100.0f, 220.0f, 9.0f)];
    
    [progressAlert addSubview:theProgressView];
    [progressAlert show];
    
    [theProgressView setProgressViewStyle: UIProgressViewStyleBar];
    
    [progressAlert show];
    
    

        NSURL *theURL;

        
        theURL= [NSURL URLWithString:downloadLink];
        request = [ASIHTTPRequest requestWithURL:theURL];
        
        NSFileManager *fileManager = [NSFileManager defaultManager];
        NSError *error;
        NSArray *paths = NSSearchPathForDirectoriesInDomains
        (NSDocumentDirectory, NSUserDomainMask, YES);
        NSString *documentsDir = [paths objectAtIndex:0];
        NSString *tempPath = [documentsDir stringByAppendingPathComponent:@"Temp"];
        
        BOOL isDir;
        
        BOOL success;
        
        if (![fileManager fileExistsAtPath: tempPath isDirectory:&isDir])
        {
            success =  [fileManager createDirectoryAtPath:tempPath withIntermediateDirectories:YES attributes:Nil error:&error];
            if (success) {
                 NSLog(@"Success  %@",tempPath);
                
            }
            else
            {
                
                    NSLog(@"Error   %@    %@",tempPath, [error description]);
                
                return;
            }
            
            
        }
        
        
        
        
        NSString *destination = [tempPath stringByAppendingPathComponent:@"myFile.pdf"];
        NSString *   temporaryFileDownloadPath=[tempPath stringByAppendingPathComponent:@"myFile.pdf.download"];
        [UIApplication sharedApplication].idleTimerDisabled=YES;
        [request setDownloadDestinationPath:destination];
        [request setTemporaryFileDownloadPath:temporaryFileDownloadPath];
        [request setAllowResumeForFileDownloads:YES];
        
        
        
    
        //  NSLog (@"dddddddd     %@" ,destination);
        //   NSLog (@"tttttt       %@" ,temporaryFileDownloadPath);
        
        
        if ([fileManager fileExistsAtPath:temporaryFileDownloadPath]) {
            //     NSLog (@"tttttt tttttttt      %@" ,temporaryFileDownloadPath);
            
        }
        
        
        //  [CallingIrevoColtroller.view addSubview:progressAlert];
    
        
        
        [request setDownloadProgressDelegate:theProgressView];
        
        //   [request setStartedBlock:^{[progressAlert show];}];
        request.showAccurateProgress=YES;
        [request setDelegate:self];
        
          [request setDidFailSelector:@selector(requestFailed:)];
          [request setDidFinishSelector:@selector(downloadDidFinish:)];
        //  [request setDidStartSelector:@selector(downloadDidStart:)];
        
        
        
        
        
        [request setRequestMethod:@"GET"];
        [request startAsynchronous];
        
   
}

- (void)downloadDidFinish:(ASIHTTPRequest *)request
{
    NSLog(@"eshta");
    [progressAlert dismissWithClickedButtonIndex:0 animated:YES];
}
- (void)requestFailed:(ASIHTTPRequest *)request
{
    [progressAlert dismissWithClickedButtonIndex:0 animated:YES];

    
    UIAlertView *alert = [[UIAlertView alloc] init];
    [alert setTitle:@"Error"];
    [alert setMessage:@"An error occurred while downloading file, please make sure your iPad is connected to the Internet click and try again."];
    [alert setDelegate:self];
    [alert addButtonWithTitle:@"Try Again"];
    
    [alert setTag:1];
    
    [alert show];
    
    
    
}



- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    
    if (alertView.tag==1) {
        
        if (buttonIndex==0) {
            
            [self getDirctLinkOfFile];
            
        }
        
        return;
    }

}




- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (DBRestClient *)restClient {
    if (!restClient) {
        restClient =
        [[DBRestClient alloc] initWithSession:[DBSession sharedSession]];
        restClient.delegate = self;
    }
    return restClient;
}

-(void)succeedToLogin
{
    self.navigationItem.rightBarButtonItem.title = @"logout";
    [[self restClient] loadMetadata:@"/"];
}
-(void)failedToLogin
{
    self.navigationItem.rightBarButtonItem.title = @"login";
    [files removeAllObjects];
    [tableData reloadData];
}
- (IBAction)authenticate:(id)sender
{
    if (![[DBSession sharedSession] isLinked])
    {
        [[DBSession sharedSession] linkFromController:self];
    }
    else
    {
        [[DBSession sharedSession] unlinkAll];
        [self failedToLogin];
    }
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSString *CellIdentifier = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    
    if(cell == nil)
    {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
    }
    
    // Configure the cell...
    
    
    cell.textLabel.text = [files objectAtIndex:indexPath.row];
    
    return cell;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 75;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return files.count;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
}


@end
