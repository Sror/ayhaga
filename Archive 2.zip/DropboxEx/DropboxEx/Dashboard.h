//
//  Dashboard.h
//  DropboxEx
//
//  Created by Mohamed Alaa El-Din on 11/5/13.
//  Copyright (c) 2013 Mohamed Alaa El-Din. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <DropboxSDK/DropboxSDK.h>
@interface Dashboard : UIViewController <DBRestClientDelegate>
{
    NSMutableArray *files;
    UIAlertView *progressAlert;
}
@property (nonatomic, readonly) DBRestClient *restClient;
@property (weak, nonatomic) IBOutlet UITableView *tableData;
@end
