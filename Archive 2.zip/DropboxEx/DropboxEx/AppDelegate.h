//
//  AppDelegate.h
//  DropboxEx
//
//  Created by Mohamed Alaa El-Din on 11/5/13.
//  Copyright (c) 2013 Mohamed Alaa El-Din. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Dashboard.h"
#import <DropboxSDK/DropboxSDK.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate,DBRestClientDelegate>

@property (strong, nonatomic) UIWindow *window;
@property (strong, nonatomic) Dashboard *dashboard;
@property (strong, nonatomic) UINavigationController *navigation;
@end
