//
//  UIDdocument.h
//  Safahat Reader
//
//  Created by Marwa Aman on 5/28/13.
//  Copyright (c) 2013 Ahmed Aly. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIDdocument : UIDocument
@property (strong) NSString * UIDString ;
@end
