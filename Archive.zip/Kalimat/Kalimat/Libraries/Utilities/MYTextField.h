//
//  MYTextField.h
//  AePubReader
//
//  Created by Ahmed Aly on 12/20/12.
//
//

#import <UIKit/UIKit.h>

@interface MYTextField : UITextField

@end
