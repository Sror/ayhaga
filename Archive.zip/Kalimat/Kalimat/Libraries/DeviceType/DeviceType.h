//
//  DeviceType.h
//  AePubReader
//
//  Created by Ahmed Aly on 11/20/12.
//
//

#import <Foundation/Foundation.h>

@interface DeviceType : NSObject{
    BOOL retinaDisplay;
    BOOL iPhone;
    
    NSString *userCountry;
}

@property (nonatomic) BOOL retinaDisplay;
@property (nonatomic) BOOL iPhone;

// Initialization
+ (DeviceType *)getObject;

// Get device type
+ (NSString *)getDeviceTypeString;

@end
