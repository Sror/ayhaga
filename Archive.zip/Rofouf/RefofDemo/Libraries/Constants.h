//
//  Constants.h
//  Safahat Reader
//
//  Created by Marwa Aman on 12/9/12.
//  Copyright (c) 2012 Ahmed Aly. All rights reserved.
//

#ifndef Safahat_Reader_Constants_h
#define Safahat_Reader_Constants_h



#endif

#define NO_DATA_KEY @"noData"
#define IS_DOWNLOADED @"isDownloaded"
#define IS_READ @"isRead"
#define ARTICLES @"articles"


#define APP_STATUS @"appStatus"

#define APP_TYPE @"0"   // 0 is live, 1 is beta

#define NO_ID @"NOID"
#define ISSUE_LIST @"issueList"
#define NEW_ISSUE @"newIssue"
#define UPDATE_LIST @"updateList"
#define Downlaod_Count @"downloadCount"



#define SendUsageNotification @"sendUsageNotification"
#define DownloadNotification @"downloadNotification"
#define AddDeviceNotification @"addDeviceNotification"
#define Font @"Droid Arabic Kufi"