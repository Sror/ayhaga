//
//  AppDelegate.h
//  Refof
//
//  Created by Mohamed Alaa El-Din on 11/6/13.
//  Copyright (c) 2013 Mohamed Alaa El-Din. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "LoginViewController.h"
#import <DropboxSDK/DropboxSDK.h>
#import "HomeViewController.h"
@interface AppDelegate : UIResponder <UIApplicationDelegate,DBRestClientDelegate>

@property (strong, nonatomic) UIWindow               *window;
@property (strong, nonatomic) UINavigationController *navigationController;
@property (strong, nonatomic) LoginViewController    *loginViewController;
@property (strong, nonatomic) HomeViewController     *homeViewController;
@end
