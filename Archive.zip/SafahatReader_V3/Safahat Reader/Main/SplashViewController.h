//
//  SplashViewController.h
//  Safahat Reader
//
//  Created by Ahmed Aly on 2/20/13.
//  Copyright (c) 2013 Ahmed Aly. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SplashViewController : UIViewController <UINavigationControllerDelegate>
@property (retain, nonatomic) IBOutlet UIActivityIndicatorView *indicatorLoading;
@property (retain, nonatomic) IBOutlet UILabel *safahatLabel ;
@end
